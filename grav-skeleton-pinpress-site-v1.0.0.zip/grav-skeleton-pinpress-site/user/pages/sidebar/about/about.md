---
taxonomy:
    category: sidebar
css_suffix: widget-about
surround: authorzo
image: about.png
social:
  - icon: facebook
    url: "#"
  - icon: twitter
    url: "#"
  - icon: google-plus
    url: "#"
  - icon: linkedin
    url: "#"
  - icon: youtube-play
    url: "#"
  - icon: envelope
    url: "#"

---

###Salman Siddiqui

Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
